#!/bin/sh
#SBATCH --account=labx
#SBATCH --hold
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --mem=32M
#SBATCH --time=00:01:00
#SBATCH hetjob
#SBATCH --account=labx
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --mem=32M
#SBATCH --time=00:01:00
true
