# Set up Raven from the toolbar

Use **Setup** in the top toolbar to choose an environment, save named site and
lab profiles, configure Heavy allocation preferences, and find the data
required by each Research and Analytics view. These pages are
included in the installed application; no browser or repository checkout is
needed to read them.

For a first installation, follow [Getting started](getting-started.md) or run
`raven setup`. Inside the dashboard, open **Setup → Installation and diagnostics → Getting started**, or enter
`:gettingstarted`. The command `:setup` opens the reference.
Press F10 to reach the
toolbar without a mouse. Use Left/Right to change menus, Up/Down to choose an
entry, and Enter to open it. Setup pages support clickable controls, arrow-key
navigation, and scrolling. Esc returns from an account picker or closes the
page; while editing a field, Esc cancels that edit.

## Choose what to configure

| Setup entry | Purpose |
| --- | --- |
| Connections and accounts | Start guided setup, choose a named site or lab profile, or review Heavy allocation preferences. |
| Launch defaults | Save workload resources, recording features, and reusable project recipes. |
| Recordings and metrics | Connect a real data file, validate samples, preview a chart, and inspect independent source readiness. |
| Refresh and performance | Adjust queue and recording-read cadence, select a Heavy preset, and find advanced performance preferences. |
| Installation and diagnostics | Check installation, terminal behavior, connection health, and effective settings. |

Opening a guide reads embedded instructions. Opening allocation settings starts
a bounded account-discovery task on the existing connection. Rendering,
hovering, and editing do not query Slurm. Discovery retains source admission,
timeouts, and shared caching; a busy or restricted scheduler can leave a field
unavailable.

## Save a named site or lab profile

Open **Setup → Connections and accounts → Sites and lab profiles**, or enter `:profiles`. Give the profile
a descriptive label and choose local Slurm, SSH Slurm, or standalone execution.
The saved profile has a stable identifier for `--site`; its label can describe
the site or lab in ordinary words.

Review the host and login separately from the Heavy account and partition.
After opening the saved profile, use **Heavy allocation settings** for QoS and
the worker's CPU, memory, GPU, and time limits. An SSH profile uses your existing
SSH configuration; do not put
passwords or private keys in Raven settings. Available account associations
belong to the current connection. Save and reconnect to a new host before using
its account-discovery results.

The profile review is read-only. Explicitly saving preserves unrelated settings
and shows the saved profile. Saving does not switch the active connection, alter
an active worker, submit a workload, or request an allocation. Select **Use this
profile** to close the old Light session and reopen Light on the saved profile,
then choose **File → Launch job**. Existing profiles provide **Use saved profile
(without saving edits)**. Release or cancel Heavy and resolve any pending launch
before switching. Command-line setup prints the equivalent
`ravenl --config PATH --site PROFILE_NAME` command.

The command-line setup supports the same review/save separation. For example,
review a local Slurm profile, then explicitly save it as the default:

```bash
raven setup --kind local-slurm --name 'My workstation' --review
raven setup --kind local-slurm --name 'My workstation' --save --default
```

Use `--config PATH` when extending a specific configuration. `raven setup
--check` prints local installation checks without modifying settings;
`--json` supplies machine-readable checks or explicit review/save output.
Interactive setup supports saving a draft with `:draft` and resuming it with
`raven setup --resume`.

The profile's account and resources configure Raven Heavy. Project launch
defaults are saved separately in `.raven/automation.json` and configure
scientific workloads. Use **File → Launch job** to review and save those choices
in the intended project; use **Project launch and recording defaults** for
advanced reporting bindings and launch recipes.

Resource fields in the guided launch workflow accept readable
units. Bare memory values mean MiB; `8 GiB` means 8192 MiB, while `8 GB` uses
decimal units and rounds upward to MiB. Time accepts seconds, `1h 30m`,
`01:30:00`, or `1-00:00:00`. The final review shows normalized values. These
conventions do not change Slurm's interpretation of directives already in a
script.

For a remote cluster, SSH monitoring and project launching remain separate:
run the guided launcher on the approved submission host where the project and
Slurm commands are accessible. Saving an SSH profile does not upload or submit
a project from the local machine.

## Set telemetry update intervals

Open **Setup → Refresh and performance**, or enter
`:refreshsettings`. The legacy `:telemetrysettings` command opens the same panel.
Presets apply immediately while Heavy is active and can
be staged from Light. Custom starts at Default; its gear button opens a
validated editor with a white-to-pink intensity scale that updates while typing.
Select **Save settings** to keep the choice for later launches.

The same panel contains independent queue and retained-recording reader controls.
It distinguishes requested intervals from actual source freshness and the job's
recording frequency. See
[telemetry updates](telemetry-updates.md) for preset values, Custom controls,
retained recording refresh, and site-policy limits.

## Configure a student's lab allocation

Suppose a student has a personal account and an association with a professor's
lab account. The student remains the authenticated user and owner of the job.
The allocation's `--account` option selects the account charged by Slurm.

1. Start `ravenl` with the intended local or cluster profile.
2. Open **Setup → Connections and accounts → Heavy allocation settings**.
3. Check the detected login, cluster, and any discovery notices.
4. Open **Choose personal / lab association** and select the actual assigned
   account. The list shows the available cluster, partition, and QoS context.
5. Set the partition and QoS required by that association. Set the CPU count,
   memory in **MiB**, GPU count, and time limit in **seconds**.
6. Select **Save settings**. Review any validation error or site-policy limit.
7. Select **Review Heavy allocation request** to inspect the effective request.
   Requesting resources uses Raven's existing separate allocation review.

**Expected result:** The saved profile supplies the next Heavy request, including
future launches of `ravenh` with that profile. Saving alone submits no job and
starts no worker. Changes cannot modify a running allocation; use the compute
controls to return to Light before saving new allocation preferences.

Slurm supplies association names, not a reliable personal-versus-lab label.
Raven therefore lists the actual associations rather than inferring a lab from
the user's name. An association is not a guarantee of a positive balance,
partition access, or permission to inspect another student's files.

The current Heavy adapter uses one node and one task. Its resource limits and
site restrictions remain effective. Heavy settings configure Raven's analysis
worker; Account and Budget monitoring retain their current account until Raven
restarts. These settings do not rewrite the application's batch scripts or charge an
existing scientific job to another account.

## Use local Slurm or a scheduler default

For a workstation running Slurm, keep the Slurm profile and choose
**Use Slurm's default account** when an explicit billing account is unnecessary.
This leaves `allocation.account` empty and omits the account flag from the
request. A local scheduler can grant resources without an allocation balance;
its configured partition, memory, CPU, and time limits still apply.

An empty account does not mean the login name is a Slurm account. On a cluster,
check which default account will be charged before using this option. A site
policy that requires an explicit account can reject it.

A standalone workstation launched with `--site desktop` has no Slurm account
or allocation. It uses the explicit local-worker policy. This is a separate
environment from a desktop that runs a local Slurm scheduler.

## Handle unavailable discovery or locked settings

| Notice or situation | Action |
| --- | --- |
| No visible associations | Use the scheduler default if appropriate, or enter the exact account assigned by the administrator. |
| SSH identity unavailable | Check the selected connection and SSH access. The local login name does not establish the remote user's identity. |
| Discovery deferred or denied | Read the notice, retain current settings, and retry after the source recovers; manual entry remains available. |
| Several clusters or partition-specific associations | Use the association for the connected cluster and verify its partition and QoS. A shared account name does not make associations interchangeable. |
| A command-line override controls a field | Relaunch without that override before changing the saved preference. |
| Configuration changed outside Raven | Relaunch Raven to load the current file, then review allocation settings before saving. |
| Heavy is active or a request is pending | Use compute controls to release or cancel it, then return to the settings page. |
| Demo or replay session | Inspect the guides; use a real configured session to discover accounts or save allocation settings. |

Saving updates the selected profile and preserves other configuration values.
A save warning about directory synchronization means the new file is visible and
the active settings were updated, but the filesystem could not confirm persistence
across a crash.
JSON and TOML are supported; saving TOML rewrites its comments and formatting.
An older unversioned configuration requires the existing explicit migration
before this editor can save it. The editor does not change authentication,
Slurm services, site policy, or another user's configuration.

## Set up a Research or Analytics view

Open the relevant Research or Analytics view and choose **Set up this view**.
The same guides remain directly available by command. For example:

```text
:setup research experiment
:setup research scaling
:setup analytics job
:setup analytics compare
```

Each page states what produces its inputs and provides the relevant controls
for opening the view, connecting a project, attaching a source, or inspecting
source health. A file of arbitrary application metrics cannot populate native
CPU or GPU curves. Completed-job curves require measurements recorded during
execution; a final total or peak cannot reconstruct a missing time series.

For complete application hooks and file examples, use
[Project reporting V2](../PROJECT_REPORTING_V2.md), the
[format cookbook](../reference/project-reporting-formats.md), and the
[metric reference](../reference/project-reporting-metrics.md).

## Save an existing-script integration

Connect the intended project, then open **Setup → Launch defaults**, or enter `:launchsetup`. This editor saves project choices without
launching a job. Configure only the bindings your application actually supplies:

- Its native metric file and explicit artifact paths.
- An array manifest and declared worker count, problem size, and repeat.
- A reporting Python path available on the execution hosts.
- Research selections, GPU/CPU recording, and a supported trace adapter.
- A named launch recipe and an existing completion-export preset.

The settings live in the project's `.raven/automation.json`. They are distinct
from Heavy allocation preferences. A scientific worker count describes a run;
it does not request scheduler resources. Keep account/partition requests in
the script or the launch's explicit scheduler options.

Use `raven launch batch.sh --recipe NAME --check` to review a saved recipe and
its sources before submission. The [launch and export
guide](automated-reporting-exports.md) describes immutable per-launch settings,
recording prerequisites, exact attempts, and export destinations.
