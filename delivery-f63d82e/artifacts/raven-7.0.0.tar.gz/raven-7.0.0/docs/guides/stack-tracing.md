# Recorded stacks and distributed trace evidence

For a shell script launched through `raven launch`, choose `--trace` to attach
supported Python processes automatically. The original script remains unchanged
and every process shares the exact reporting attempt. Explicit `raven_exec`,
native instrumentation, distributed adapters and current-stack snapshots remain
available for their respective coverage.

For a complete exercise, use the [heat-diffusion trace lab](../../examples/trace-lab/README.md).
Its launch and viewer scripts preserve an exact receipt, with instructions for
live Slurm inspection, History, and standalone CLI inspection. Nested solver
calls, spawned analysis workers, scientific metrics, and deliberate failure
provide several paths to explore without extra application dependencies.
Optional MPI and CUDA variants use mpi4py and PyTorch respectively. All normal
runs include about two minutes of pacing for live inspection; CUDA records
Python host calls rather than device kernels.

## Automatic attachment

Keep the application's existing Bash command, for example `python3 solve.py`,
then launch on Slurm:

```bash
raven launch job.sh --project "$PWD" --research experiment --trace
```

Use `--local` only to execute on the current workstation. Add `--account LabX`
for a lab account available to your login. The default monitoring adapter needs
CPython 3.12 or later. On Python 3.10/3.11, explicitly consent to the reduced
profile adapter with `--trace-adapter python-legacy-profile`.

The supervisor supplies a private `sitecustomize` directory through `PYTHONPATH`.
Interpreters that inherit it attach before the application's first line. Existing
site customization is chained and recorded. No source rewriting, application
Raven installation, or hand-written job hook is needed.

| Application start | Python coverage |
| --- | --- |
| `python3 solve.py`, `python -m package`, `python -c`, Python shebang | Automatic attachment when startup imports the supplied site hook. |
| Subprocess, multiprocessing spawn/fork, process pool | Separate process journals, each bound to the same run attempt. |
| `torchrun` / DDP | Separate workers with discovered rank and local rank; Python frames only. |
| `srun` / MPI Python tasks | Separate rank journals when the launch environment is propagated. |
| DataLoader and pool helpers | Recorded and identified as helpers; hidden from the default trace view. |
| Threads / asyncio | Observed Python events and thread IDs; not a complete logical task or distributed stack. |
| Native libraries, CUDA/NCCL kernels, compiled solvers | No automatic native/device event capture. |

The default `--trace-scope project` records code under the project root and
declared script directory. Standard-library, installed dependency and Raven
implementation frames are excluded at capture. `--trace-scope all` broadens
Python scope and may substantially increase overhead and storage. It does not
add native or GPU stacks. `--trace-helpers` includes helper workers in the
default view. Trace controls show process role, rank, PID, observed events and
coverage gaps independently; separate process clocks do not establish causal
ordering without explicit links.

Use the retained [explicit hook](automated-reporting-exports.md#6-trace-a-supported-application-launch)
after module loads when a particular command needs an override:

```bash
source "$RAVEN_SHELL_HELPER"
raven_exec python3 solve.py
```

The hook guards against double attachment. To use only explicitly hooked
commands, launch with `RAVEN_TRACE_AUTO=0 raven launch job.sh --trace`. A hook
on one command cannot undo automatic attachment in commands already started.

### Understand attachment gaps

`python -I` ignores the injected Python path and `python -S` skips site startup.
An environment activation that replaces `PYTHONPATH` can also remove the hook.
Older interpreters, unavailable monitoring IDs, profiler conflicts and exhausted
recording budgets leave explicit coverage limitations when Raven can observe
them. An attached parent's observed subprocess launch can diagnose supported
exclusions, but **the site hook cannot observe arbitrary children launched by an
untraced shell**. No recorded process is not proof that the script ran no Python.
Use a simple pilot and inspect the per-process index on the actual site.

Module systems, launchers and remote ranks must propagate the launch environment
and see the runtime bundle on shared storage. A local shaped-rank fixture does
not qualify Slurm launch, multi-node MPI, GPU kernels or a production filesystem.
See the [runnable examples](../../examples/automated-reporting/README.md) for
plain Python, process pools, optional CPU DDP and mpi4py.

### Read committed evidence

New automatic recordings batch events into hash-chained blocks. Readers verify
each committed block and advance through bounded windows instead of retaining
the entire journal or repeatedly showing only its first prefix. Existing event
journals remain readable. A corrupted committed block fails integrity checks;
an incomplete final block is an uncommitted tail, not a valid observation.

Default limits are 64 MiB per process, 256 MiB per run and 128 process streams.
`--trace-process-bytes`, `--trace-run-bytes` and `--trace-processes` set explicit
limits. Saved launch recipes use the corresponding underscore-named fields.
Raise limits only after checking the workload's event rate and available storage;
more storage does not imply more complete instrumentation.

Buffers and budgets bound resource use. The flush cadence is not a per-event
durability guarantee: crashes, slow storage and forced termination can lose
uncommitted observations. The manifest distinguishes observed and committed
coverage. A low overhead target is workload-dependent; filtering and batching
do not establish a universal slowdown bound.

Automatic callbacks enqueue bounded tuples; a background writer validates and
encodes them. Code metadata is stored once and verified readers expand its
references. Durable checkpoints and manifest publication occur at most once
per second during capture, plus explicit shutdown. The callback buffer holds
at most 65,536 events. Exhaustion stops recording with a visible incomplete
prefix; Raven does not silently sample or drop old frames to appear faster.
An application callback does not wait for the writer's storage operations.

By default, helper workers have a separate pool of up to 32 process slots and
32 MiB, bounded by one quarter of the process limit and one eighth of the run
byte limit. Main processes and ranks retain the remaining capacity. With
`--trace-helpers`, all observed processes deliberately share the configured run
budget. A fork-then-exec child consumes no recording slot until project Python
actually resumes. Active tracing uses a writer thread; ordinary metrics writers
exit while idle. Fork handlers pause I/O with a short bounded wait and close
inherited descriptors in children; a stalled filesystem does not impose an
unbounded pre-fork wait. Active multithreaded capture can still trigger Python's
general fork-with-threads warning. Prefer `spawn` or `forkserver` for applications
whose libraries require that stronger process boundary.

The live terminal/browser view retains a bounded window. CLI `trace export`,
`trace inspect`, and `trace summary create` traverse the entire verified
committed prefix in bounded pages, including intervals crossing page boundaries.
They use a private disk-backed spool capped at 256 MiB and a 60-second traversal
budget; explicit export/inspection artifacts are capped at 32 MiB. A limit or
late integrity failure produces an error rather than a successful truncated
artifact. The source journal remains unchanged.

### Reuse and clean up launch runtimes

Launches reuse content-addressed runtime archives and extracted bytecode caches.
These caches are private project metadata, not application dependencies. Payload
files remain read-only while their owning wrapper directory permits cleanup.

```bash
# Preview completed launch wrappers older than 30 days.
raven trace cleanup-runtime --project "$PWD"
# Apply the reviewed cleanup; recordings/results in runs/ remain available.
raven trace cleanup-runtime --project "$PWD" --apply
```

`--older-than-days 7` changes retention. Active, queued and unverified wrappers
are preserved. Slurm wrappers additionally require a successful check that the
exact job is absent from the queue on its retained original connection, user,
Slurm configuration selectors and actual cluster. Select that same local Slurm
profile when cleaning up. Confirmation uses the shared collection ledger, one
batched queue read for at most 128 exact job IDs; an unknown configured cluster
requires one additional bounded `scontrol show config` read. Deferred budgets,
unknown/mismatched cluster identities and legacy launches without retained
connection evidence preserve their wrappers. Terminal run metadata alone does
not authorize deleting a queued or requeued wrapper.
Shared archive/extracted caches remain available for detached descendants and
future launches. Cleanup never deletes scientific results, logs or recordings.

Use Raven to record a prepared Python program, receive cooperative native
events, reconstruct recorded stacks, inspect explicit causal links, and audit
supported collective signatures. A running local Python process can provide a
reviewed, nonblocking snapshot when `py-spy` is installed and job membership can
be verified. The table below lists each method's runtime prerequisites.

Coverage is limited to the selected instrumentation. Checksums and sequence
numbers verify journal integrity; they do not establish that an uninstrumented
function, device, process, or runtime emitted an event.
Storage exhaustion stops recording and marks the trace incomplete. A crash can
leave an unknown tail after the last durable checkpoint. Native socket writes
acknowledge transport acceptance, not per-event durable storage.

## Choose a capture method

| Method | Preparation | Recorded scope | Important limit |
| --- | --- | --- | --- |
| `raven launch --trace` | Existing Bash script; CPython 3.12+ or explicit legacy consent | Project Python frames in automatically attached processes and threads | Environment propagation and supported startup are required; no native/device internals |
| `raven trace run` | Launch a Python script with Raven under CPython 3.12 or later | Python call, resume, return, yield, throw-resume and unwind events, including observed threads | No native-extension internals, GPU execution or automatic fork-child capture in this standalone path |
| `raven trace run --legacy-profile` | Explicitly select the legacy adapter | Python profile call/return events on supported Python 3.10 or later | Cannot reliably distinguish generator yields, returns and exception unwinds |
| `raven trace native` | Compile explicit calls to the cooperative SDK | Events supplied by local C/C++ processes and threads | No automatic native unwinding; private inherited sockets do not cross SSH or `srun` automatically |
| PMPI source adapter | Compile the optional adapter against the application's MPI runtime | Automatic C-binding WORLD Barrier, scalar Bcast and scalar Allreduce/SUM metadata | At most 256 ranks; no thread-multiple, Fortran, nonblocking or arbitrary communicator coverage |
| `Trace → Capture current Python stacks` | Install `py-spy`, run Raven on the target process node, and review a verified job/PID | One non-atomic set of observed Python stacks | No previous history; permission or runtime support may prevent capture |

Rust, OCaml, MPI and GPU applications can report the same cooperative events
through an application adapter or C FFI. This is a protocol integration point,
not a claim that automatic adapters for those runtimes are installed. There is
no debugger, kernel permission change, extra MPI barrier or public TCP listener.

## Record a Python job from its start

Use the launch command inside the job's existing allocation:

```bash
raven trace run \
  --project "$PROJECT_DIR" \
  --job-id "$SLURM_JOB_ID" \
  --attempt "$RAVEN_RUN_ID" \
  --max-mib 64 \
  -- train.py --epochs 20
```

Set `PROJECT_DIR` to an existing project directory. Use the exact Raven run ID
from project reporting, or an explicit scheduler `SubmitTime/StartTime` string
as `--attempt`. Optional `--slurm-submit` and `--slurm-start` fields let Raven
verify the scheduler attempt independently. Array tasks should use their exact
`array_job_id_array_task_id` identity, not an array parent. Specify `--job-id`
when the launch environment does not already identify the exact task.

The recorder prints its manifest path. Open Raven, select the matching job, and
select **Trace** in Details. Raven discovers registered traces under that
project. Automatic association requires a matching attempt or project run ID.
An ambiguous old job ID must not attach automatically.

```text
:trace
:trace attach /project/.raven/traces/STREAM/manifest.json
:trace refresh
:trace pause
:trace follow
:trace select 0
:trace clear
```

Explicit attachment displays identity verification status. **Pause** pauses the
view, not recording. Closing Raven does not stop a separately running recorder.
Do not change the sampling sliders to control this recorder: its input is
event-driven. Display refresh and event capture are separate.

### Explore the visual timeline

Select a job in Jobs or History, open **Trace**, and choose **Timeline**. Time
runs left to right; nested Python calls occupy successive depth rows. Each bar
has a matched recorded entry and exit. Cooperative spans use separate lanes;
their overlap does not establish a parent/child relationship.

Choose a process from the existing process list, then a thread. Use **Zoom +**,
**Zoom -**, **Pan**, and **Fit window** to explore its retained window. Click a
call to see its full name, wall duration, source definition and event sequences.
**Focus** zooms around that interval. With Trace content focused, `+`/`-`
zoom, Left/Right pan, `f` fits, `n`/`N` move between calls, and `t` changes thread.
The command palette provides the same actions:

```text
:trace timeline
:trace find solve
:trace next
:trace focus
:trace fit
:trace events
```

Use `:trace find` without a name to clear the search. **Events** preserves the
original retained event view; **Summaries** provides aggregate duration queries.
Pausing, selecting a different process, and viewing a completed job all use the
same exact-attempt recording checks.

Choose **View in browser** for an interactive flame timeline with zooming,
panning, search, thread selection and call details. Raven writes a private,
self-contained HTML snapshot of the current retained window, then requests a
local browser. It does not upload the recording, require a website, or start a
web server. The browser snapshot is static; use the terminal view for live
updates, or export again for a newer snapshot.

For a headless cluster session, export an HTML file explicitly, transfer it to
your workstation using your normal file-transfer method, and open it locally:

```bash
raven trace export /path/to/manifest.json --format html \
  --output "$HOME/raven-trace-$(date +%s).html"
```

Replace `/path/to/manifest.json` with the manifest printed by the recorder or
shown in the Trace view. Output files are created exclusively; existing files
are never overwritten. CLI export reads a bounded verified prefix, while the
Trace button exports the current retained window. The file identifies its
process, attempt, sequence coverage, evicted events and unknown boundaries.

This interaction follows the time-versus-stack approach used by
[Magic Trace](https://blog.janestreet.com/magic-trace/). Raven visualizes its
existing recordings: it does not collect Intel Processor Trace, native library
internals, or CUDA kernels through this viewer. Recorded durations are inclusive
wall time, not CPU utilization. Empty regions, unfinished calls and loss markers
remain unknown; Raven does not invent closing events or align independent MPI
process clocks. Use the existing Perfetto export when another compatible trace
viewer is preferred.

### Inspect sockets and physical cores

For a future Python job, request CPU-placement observations explicitly:

```bash
raven launch job.sh --project "$PWD" --trace --trace-cpu-placement
```

The equivalent standalone recorder option is `raven trace run --cpu-placement`.
The launch setup page also offers a CPU-placement checkbox when tracing is
selected. It is disabled by default because querying placement adds work and
metadata to every eligible event.

Select **CPU cores** in Trace, or choose **CPU placement observations** in the
browser. Lanes identify the selected process's observed **socket → physical core
→ logical CPU**. Linux IDs are shown as recorded, starting at zero where the
system uses zero. Logical CPUs can be simultaneous hardware threads on the same
physical core; a process thread is a separate identity. The thread selector
filters observations without relabeling threads as cores.

Each point shows where the emitting thread was observed during a bounded
`sched_getcpu` query. Details preserve the query's start/end timestamps and
original event sequence. The query bracket measures observation uncertainty,
not time spent running on that core. Raven does not assign a whole function to
its entry core, connect sparse points into continuous residency, or draw missing
cores as idle. Calls and CPU observations remain complementary views.

This software adapter uses Linux APIs rather than vendor-specific instructions,
so its prerequisite is the available OS/runtime interface on AMD, Intel, Arm,
or another processor. Missing physical topology is shown as `?`. Unsupported
platforms and old recordings retain the call timeline and explain why CPU
placement is unavailable. No Intel PT, scheduler-switch recording, device tracing
or elevated permission is added by this option. Read the
[capture capabilities guide](trace-capabilities.md) before qualifying a new
execution platform.

Python monitoring needs an unused `sys.monitoring` tool ID. The legacy profile
adapter refuses to replace an existing profiler. Recording excludes its own
implementation. Forked Python children do not append to the parent's journal.
The automatic launch adapter creates separate child recorders; standalone or
cooperative instrumentation must arrange its own child capture. Native instructions, existing frames at
attachment, signal-handler completeness and unprepared children are outside the
declared Python coverage.

The event recorder displays each Python function's definition line. It does
not enable per-line instruction events, so that number is not a live program
counter. Use a current-stack snapshot when the presently observed source line
is needed. Physical thread stacks do not establish a complete logical async
task or distributed GPU stack.

## Capture a running Python process without restarting it

Open the **Capture current Python stacks** operation, or run:

```text
:ops trace-snapshot
```

Enter the running job ID, its local process PID, and the project directory.
Inspect the review, then apply it. Raven checks the live scheduler owner and
submit/start identity, node-local `scontrol listpids` membership, Unix ownership,
and `/proc` process start identity. It repeats these checks before capture and
rejects a process that changes during capture.

The adapter runs only:

```text
py-spy dump --pid PID --json --nonblocking
```

The command has a five-second timeout and a 1 MiB output bound. Raven neither
requests native unwinding nor changes `ptrace` policy. Nonblocking reads can
observe inconsistent frames. The saved journal is labeled **snapshot**, with
incomplete execution coverage. If `py-spy` is unavailable or the node cannot
verify job membership, Raven reports that limitation instead of attaching to
an arbitrary process belonging to the same user.

## Add cooperative application events

The Python SDK uses only the standard library:

```python
from raven.trace_recorder import Recorder

with Recorder(project_dir, job_id=job_id, attempt=run_id) as trace:
    with trace.span("load input", span_id="load") as load:
        load_input()
    with trace.span("calculate", span_id="calculate") as calculation:
        calculate()
    trace.link(load, calculation, relation="precedes")
```

`span()` returns the globally qualified `stream:span_id`. Supply unique span
IDs within a stream. Use `parent_id` to declare nesting. A `precedes` link means
the source finished before the target started. Do not use it merely because
two operations are related or overlap.

`Recorder.emit(kind, data, thread=...)` accepts bounded JSON metadata. It rejects
terminal control characters, oversized values, nonfinite numbers and excessive
nesting. It does not capture local variables or user data automatically. The
return value is false if recording has stopped. `flush()` establishes a durable
journal checkpoint; it can add filesystem latency. `close()` publishes a clean
end when recording has not failed.

Generate the standalone native header:

```bash
raven trace native --sdk-header > raven_trace.h
cc -D_GNU_SOURCE -pthread program.c -o program
raven trace native --project "$PROJECT_DIR" --job-id "$SLURM_JOB_ID" \
  --attempt "$RAVEN_RUN_ID" -- ./program
```

```c
#include "raven_trace.h"

int main(void) {
    raven_trace_emit("span_start",
        "{\"span_id\":\"solve\",\"name\":\"solve\"}");
    /* application work */
    raven_trace_emit("span_end", "{\"span_id\":\"solve\"}");
    return 0;
}
```

The header works with C and C++ on Linux. It uses a private inherited Unix
`SOCK_SEQPACKET` descriptor. Packets are limited to 4096 bytes. Each PID/start
time/thread has a separate stream. The native collector uses one event loop,
not a background thread per application thread. The default stream limit is
64; `--max-streams` can select 1–256.

The SDK returns `0` for a successful transport write, `1` when recording is not
enabled, and `-1` for failure. Writes can block under backpressure. Do not call
it from signal handlers, allocation hooks, or sensitive internal locks. A
collector failure must not be interpreted as proof that all events were saved.
No device memory, MPI payload or tensor data is copied automatically.

For multiple nodes, launch the adapter beside each participating application
process through the site's ordinary allocation launch method. Use a shared,
authorized project path if Raven must discover all streams there. Node-local
storage is preferable for heavy recording, but must be staged explicitly before
another host can inspect it. There is no automatic remote transport service in
this release.

## Capture supported MPI collectives automatically

The optional PMPI adapter records supported calls without adding explicit SDK
calls to the application. Compile it with the **same MPI compiler and runtime**
used by the application. Existing profilers can also use PMPI or `LD_PRELOAD`;
check compatibility before combining them.

```bash
raven trace native --sdk-header > raven_trace.h
raven trace mpi --source > raven_mpi.c
mpicc -std=c11 -D_GNU_SOURCE -fPIC -shared raven_mpi.c -o libraven_mpi.so
```

Launch the native collector **inside each rank launch**. For example, adapt the
site's normal `srun` invocation as follows:

```bash
srun raven trace native \
  --project "$PROJECT_DIR" --job-id "$SLURM_JOB_ID" --attempt "$RAVEN_RUN_ID" \
  -- env LD_PRELOAD="$PROJECT_DIR/libraven_mpi.so" \
  RAVEN_MPI_COMM_GENERATION="$RAVEN_RUN_ID" ./mpi_program
```

`RAVEN_MPI_COMM_GENERATION` must be the same nonempty identifier on all ranks.
Use only letters, digits, `.`, `_` and `-`, with a maximum of 128 characters.
Do not reuse a generation for distinct MPI worlds in the same job attempt.
Multiple independent worlds require distinct identifiers.

The **Prepare trace launch** operation also accepts `adapter=mpi`, the compiled
library path, and the shared generation. Its command is a rank-local wrapper;
the user retains the existing scheduler allocation and MPI launcher.

The current automatic scope is:

- C bindings for `MPI_Init`, `MPI_Init_thread`, and `MPI_Finalize`.
- `MPI_COMM_WORLD` with at most 256 ranks.
- `MPI_Barrier`, scalar `MPI_Bcast`, and scalar `MPI_Allreduce` with `MPI_SUM`.
- MPI thread levels SINGLE, FUNNELED and SERIALIZED.
- Compatible built-in float, double, integer and byte datatypes listed in the
  generated source. No derived datatype interpretation.

The adapter records entry and observed completion. It does not add a barrier,
extra collective, payload copy, kernel counter, or device read. Unsupported
communicators, datatypes, operators, oversized worlds, or THREAD_MULTIPLE
produce an explicit gap. MPI functions outside this wrapper set are outside
its declared scope. A gap prevents an overall complete result.

This implementation has real two-rank Open MPI 5.0.7 tests for successful
Barrier/Bcast/Allreduce, unsupported MAX reduction, COMM_SELF, thread-multiple,
and missing generations. These tests validate actual wrapper execution and
unchanged program results on one host. They do not qualify all MPI ABIs,
multi-node transports, Fortran bindings, or production launch policies.

## Inspect causal delays

Open **Causal delay explorer**, or use `:ops causal-delay`. Select a trace
manifest. To combine registered process/rank streams, select the project
directory and provide the exact job ID and attempt.

The analyzer validates explicit span IDs, durations, nesting and dependency
edges. It rejects cycles and impossible same-stream finish-before-start edges.
It calculates a longest chain of recorded leaf-span durations. Nested parents
remain visible and are not counted twice.

This duration is not global wall-clock makespan or a predicted speedup. Raven
does not subtract timestamps from different nodes or infer clock alignment.
Missing edges, unsupported relationship semantics, gaps and incomplete spans
remain visible. The default operation budget is 20,000 events and 8 MiB across
at most 256 registered streams. The live reader continues incrementally; an
offline operation reports when its bounded input is partial.

## Audit collective signatures

Emit `collective` events with the following fields:

```python
trace.emit("collective", {
    "communicator": "training-world",
    "generation": "run-1-world-0",
    "sequence": 42,
    "operation": "allreduce",
    "members": [0, 1],
    "rank": 0,
    "dtype": "float32",
    "count": 1024,
    "reduction": "sum",
    "phase": "enter",
})
# Emit the same signature with phase="complete" after observed completion.
```

The communicator and generation must be agreed across ranks. A local MPI
communicator pointer is not a portable identity. Do not add collectives or
barriers only to feed this monitor. Route metadata through the cooperative
side channel.

Open **Collective protocol auditor**, or use `:ops collective-audit`. The
initial supported signatures are scalar AllReduce, Bcast/Broadcast and Barrier.
The auditor distinguishes disagreement, incomplete participation, unfinished
operations and unsupported semantics. Derived datatypes and variable-count
collectives require a future adapter. Missing ranks are not proof of deadlock.
Results never cancel a job or alter a collective.

## Project files and durability

```text
PROJECT/
  .raven/
    traces/
      index.json
      STREAM/
        manifest.json
        events.jsonl
```

`index.json` uses `raven.trace-index/v1` and explicitly binds relative manifest
paths to job, attempt and stream identity. The `raven.trace/v1` manifest contains
cluster, job ID, attempt, node, boot ID, PID, process start, stream, coverage,
state, committed sequence and committed byte count. It can also include the
project run ID and scheduler submit/start values. Identity changes require a new
stream; readers reject replacement or regressed checkpoints.

Each `raven.trace-event/v1` JSONL envelope contains `stream`, `seq`, `prev`,
`event`, and `sha256`. The event contains `kind`, `mono_ns`, `thread` and `data`.
The digest is SHA256 over the canonical sorted-key, compact, ASCII JSON envelope
without `sha256`. `prev` links to the previous digest. The first sequence is 1
and the first `prev` is 64 zeroes. Duplicate records in the stored journal,
sequence gaps, corruption and clock regression invalidate the committed prefix.
The pure analysis API can deduplicate matching transport replay; the writer
does not silently accept duplicates into its journal.

The recorder fsyncs event bytes before publishing the commit checkpoint through
an atomic manifest replacement. The default checkpoint interval is 50 ms or 64
events. UI reads use only this committed prefix. A crash between checkpoints
can lose later events. Filesystem durability also depends on the storage system.
The manifest state and `complete` flag describe only the declared recording
scope. A `COMPLETE` recording does not establish universal execution coverage.

## Resource and validation limits

Recording every Python frame adds work and data. Import-heavy applications can
produce tens of thousands of events before useful computation begins. Measure
overhead on a representative allocation and reserve explicit CPU, memory and
storage. Raven does not promise a fixed overhead percentage. Cooperative spans
let an application declare a smaller scope; this is a separate capture choice,
not a silent fallback from complete frame recording.

A local qualification workload used 200 Python calls, each with 15,000 integer
arithmetic iterations. With CPython 3.12 and three repetitions, median complete
process time was **0.211 seconds without recording and 0.415 seconds with
recording**. Each recorded run wrote 4,163 events and approximately 2.28 MB,
including Python import and launcher activity. This is about 1.97 times the
baseline time for that specific small workload. It is not a cluster performance
claim or a fixed overhead bound.

Reading that backlog with a 15 ms worker budget used 10–11 slices. Observed
slices reached 18.4 ms on the shared test host; a caught-up refresh took about
0.19–0.23 ms. The time budget yields between records and cannot bound filesystem
latency or OS scheduling. Reads and analysis stay outside rendering. A busy
recording can accumulate backlog, which the view reports instead of skipping
unvalidated history.

Automated checks exercise real CPython capture with threads, recursion,
exceptions, generators and async functions; compiled C/C++ programs with
threads and fork; durable journals; corruption; process identity; cancellation;
storage limits; multi-stream causal paths; and collective signatures. Snapshot
tests exercise real journals and `/proc`, with Slurm and `py-spy` execution
fixtures. This environment does not certify production Slurm, MPI, GPU devices,
all compilers/runtimes, distributed filesystems or site permission policies.

For installations with development headers, run the actual MPI adapter tests
with `python -m pytest -q tests/test_trace_mpi.py`. If only the Open MPI runtime
is installed, a matching development package can be extracted into a user-owned
directory for validation. Set `RAVEN_TEST_MPI_INCLUDE` to its Open MPI include
directory and, if required, `RAVEN_TEST_MPI_LINK` to the matching linker flags.
These test variables do not change application launch configuration.

## Export an interoperable view

Use `raven trace export MANIFEST --format perfetto --output NEW.json` for a
bounded timeline, or `--format speedscope` for supported Python evented frame
intervals. Both preserve the verified-prefix identity, coverage limits, and
integrity evidence. See [self-tracing and application trace exports](self-tracing.md)
for examples, limits, and the distinction between wall-time intervals and CPU
sampling. Existing v1 journals and readers remain compatible; recording still
uses per-event checksums and explicit durable commit checkpoints.
